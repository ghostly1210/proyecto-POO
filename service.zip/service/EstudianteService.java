package com.studentorganizer.service;

import com.studentorganizer.model.Estudiante;
import java.util.HashMap;
import java.util.Map;

public class EstudianteService {
    private static Map<String, Estudiante> estudiantes = new HashMap<>();
    
    public boolean registrarEstudiante(String email, String password, String nombre, String carrera) {
        if (estudiantes.containsKey(email)) {
            return false; // Email ya existe
        }
        
        Estudiante nuevoEstudiante = new Estudiante(nombre, carrera, email, password);
        estudiantes.put(email, nuevoEstudiante);
        return true;
    }
    
    public Estudiante autenticarEstudiante(String email, String password) {
        Estudiante estudiante = estudiantes.get(email);
        if (estudiante != null && estudiante.getPassword().equals(password)) {
            return estudiante;
        }
        return null;
    }
    
    public boolean existeEmail(String email) {
        return estudiantes.containsKey(email);
    }
}